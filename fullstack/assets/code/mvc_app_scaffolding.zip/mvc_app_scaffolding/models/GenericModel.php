<?php

// MODELO GENÉRICO (ADAPTAR A CADA TABLA CONCRETA)

class GenericModel
    private $db;

    public function __construct()
    {
        // Instanciamos la capa de abstracción de datos
        $this->db = new Database("mariaDB", "nombre-bd", "usuario-bd", "password-bd");
    }

    public function getAll()
    {
        $sql = "SELECT * FROM nombre_tabla";  // Añadir INNER JOIN si es necesario
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }

    public function get($id)
    {
        $sql = "SELECT * FROM nombre_tabla WHERE id = :id";
        $stmt = $this->db->prepareAndExecute($sql, [":id" => $id]);
        return $stmt->fetch(PDO::FETCH_OBJ);
    }

    public function getMaxId()
    {
        $sql = "SELECT MAX(id) AS lastId FROM nombre_tabla";
        $stmt = $this->db->query($sql);
        return $stmt->fetch(PDO::FETCH_OBJ)->lastId;
    }

    public function insert($campo1, $campo2, $campo3)  // Adaptar los parámetros según la tabla
    {
        $sql = "INSERT INTO nombre_tabla (campo1, campo2, campo3)
                VALUES (:campo1, :campo2, :campo3)";
        $stmt = $this->db->prepareAndExecute($sql, [
            ":campo1" => $campo1,
            ":campo2" => $campo2,
            ":campo3" => $campo3
        ]);
        return $stmt->rowCount();
    }

    public function update($id, $campo1, $campo2, $campo3)  // Adaptar los parámetros según la tabla
    {
        $sql = "UPDATE nombre_tabla SET
                    campo1 = :campo1,
                    campo2 = :campo2,
                    campo3 = :campo3
                WHERE id = :id";
        $stmt = $this->db->prepareAndExecute($sql, [
            ":campo1" => $campo1,
            ":campo2" => $campo2,
            ":campo3" => $campo3
        ]);
        return $stmt->rowCount();
    }

    public function delete($id)
    {
        $sql = "DELETE FROM nombre_tabla WHERE id = :id";
        $stmt = $this->db->prepareAndExecute($sql, [":id" => $id]);
        return $stmt->rowCount();
    }

    public function search($textoBusqueda)
    {
        $sql = "SELECT * FROM nombre_tabla
                WHERE campo1 LIKE :texto
                   OR campo2 LIKE :texto
                   OR campo3 LIKE :texto";  // Adaptar los campos según la tabla. Añadir INNER JOIN si es necesario
        $param = "%" . $textoBusqueda . "%";
        $stmt = $this->db->prepareAndExecute($sql, [":texto" => $param]);
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
}