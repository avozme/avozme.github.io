<?php

// --------------------------------------------------
// Capa de abstracción de datos con PDO
// --------------------------------------------------
class Database
{
    private $pdo;

    public function __construct($host, $dbname, $user, $pass)
    {
        $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
        try {
            $this->pdo = new PDO($dsn, $user, $pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error en la conexión: " . $e->getMessage());
        }
    }

    // Ejecutar SELECT sin parámetros
    public function query($sql)
    {
        return $this->pdo->query($sql);
    }

    // Ejecutar SELECT o acción con parámetros
    public function prepareAndExecute($sql, $params = [])
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    // Devuelve el último id insertado
    public function lastInsertId()
    {
        return $this->pdo->lastInsertId();
    }
}