<?php

class Config {
    public static $dbhost = 'localhost';
    public static $dbuser = 'root';
    public static $dbpass = 'Celia2021';
    public static $dbname = 'acl';
}

